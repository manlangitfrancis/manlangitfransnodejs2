const main = {
    index:(req, res) =>{
        res.render('index');
    },
    testimonial:(req, res) =>{
        res.render('testimonial');
    },
    error:(rleq, res) =>{
        res.render('404');
    },
    about:(req, res) =>{
        res.render('about');
    },
    blog:(req, res) =>{
        res.render('blog');
    },
    contact:(req, res) =>{
        res.render('contact');
    },
    project:(req, res) =>{
        res.render('project');
    },
    service:(req, res) =>{
        res.render('service');
    },
    team:(req, res) =>{
        res.render('team');
    }

    
}
module.exports = main;